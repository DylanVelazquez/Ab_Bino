function ContarMultiplosde2(p){
    if(p % 2 == 0){
        return true;
    }else {
        return false;
    }}
function ContarMultiplosde3(p){
    if(p % 3 == 0){
        return true;
    }else {
        return false;
    }}
function ContarMultiplosde4(p){
    if(p % 4 == 0){
        return true;
    }else {
        return false;
    }}
function ContarMultiplosde5(p){
    if(p % 5 == 0){
        return true;
    }else {
        return false;
    }}